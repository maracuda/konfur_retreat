# Визуализация для Code Retreat: Муравей Лэнтона

Для работы визуализатора необходимо загрузить Json-файл.
Примеры готовых файлов для каждой сессии находятся в директории `results`.

На каждую сессию есть свой readme. Их можно найти по следующим ссылкам:
- [Simple](https://github.com/lgnv/LangtonAnt/blob/simple/visualization/readme.md)
- [Map](https://github.com/lgnv/LangtonAnt/blob/map/visualization/readme.md)
- [Colors](https://github.com/lgnv/LangtonAnt/blob/colors/visualization/readme.md)
- [Hex](https://github.com/lgnv/LangtonAnt/blob/hex/visualization/readme.md)